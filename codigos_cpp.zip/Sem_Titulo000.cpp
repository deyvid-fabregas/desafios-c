#include <stdio.h>

int main ()
{
  float bruto, p1, p2;
  printf(" salario bruto: R$ ");
  scanf("%f", &bruto);
  printf("Desconto 1 (%%): ");
  scanf("%f",&p1);
  printf("desconto 2 (%%): ");
  scanf("%f",&p2);

  float d1 = bruto * p1 / 100.0f;
  float d2 = bruto * p2 / 100.0f;
  float final = bruto - d1 - d2;
  printf("valor descontado 1: %.2f", d1 );
  printf("\nvalor descontado 2: %.2f ", d2);
  printf("valor final: %.2f", final);
  return 0;
}
