#include <stdio.h>

int main(){
int qtd;
printf("quantidade em estoque ");
scanf("%d", &qtd);

if (qtd > 0){
    printf("disponivel");
}
else {
    printf ("protudo nao disponivel");
}
return 0;
}
